import React from "react";
import { useSelector } from "react-redux";
const Dashboard = () => {
  const userList = useSelector((state) => state.userList.userList);
  console.log(userList);
  return <div>Dashboard</div>;
};

export default Dashboard;
