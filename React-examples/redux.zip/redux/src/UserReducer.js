const INITIAL_STATE = {
  userList: [],
};

const UserReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case "addUser":
      return {
        ...state,
        userList: [...state.userList, action.payload],
      };
    default:
      return state;
  }
};

export default UserReducer;
