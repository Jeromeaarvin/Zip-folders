import { ADDUSER } from "./Action-type";
const addUser = (user) => {
  return {
    type: ADDUSER,
    payload: user,
  };
};
export default addUser;
