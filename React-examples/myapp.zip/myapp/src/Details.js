import React, { useContext } from "react";
import { AppContext } from "./AppContext";

function Details() {
  const { val, profilePhoneNumber, setProfilePhoneNumber, setBikeName } =
    useContext(AppContext);
  return (
    <div>
      {" "}
      {profilePhoneNumber}
      <input onChange={(e) => setBikeName(e.target.value)}></input>
      Details
    </div>
  );
}

export default Details;
