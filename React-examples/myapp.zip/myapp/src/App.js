import logo from "./logo.svg";
import AppContextProvider from "./AppContext";
import Profile from "./Profile";
import Details from "./Details";
import "./App.css";
import { useState } from "react";

function App() {
  const [user, setUser] = useState("sethu");
  return (
    <div className="App">
      <AppContextProvider>
        <Profile></Profile>
        <Details></Details>
        <></>
        <></>
      </AppContextProvider>
    </div>
  );
}

export default App;
