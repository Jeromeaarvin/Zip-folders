import React, { useState } from "react";

import Button from "./Button";
const Count = ({ text, count }) => {
  console.log("Count rendering");
  const [listOfInputs, setListOfInputs] = useState(["username", "password"]);
  const countClick = () => {
    console.log("count click");
  };

  return (
    <div>
      <Button click={countClick} listOfInputs={listOfInputs}>
        Login
      </Button>
    </div>
  );
};

export default Count;
