import React, { useState } from "react";
import Button from "./Button";

const Title = () => {
  console.log("Title Rendering");
  const [listOfInputs, setListOfInputs] = useState([
    "username",
    "name",
    "email",
    "password",
  ]);
  const btnClick = () => {
    console.log("title click");
  };
  return (
    <div>
      <Button click={btnClick} listOfInputs={listOfInputs}>
        Register
      </Button>
    </div>
  );
};

export default Title;
